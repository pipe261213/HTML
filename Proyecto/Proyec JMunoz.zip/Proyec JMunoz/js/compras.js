function calcular() {
    var producto = document.getElementById("prod1").value;
    var unidades = document.getElementById("uni").value;

    var valorUnitario = parseFloat(producto);
    var valorTotal = valorUnitario * unidades;

    document.getElementById("vau01").value = "$" + valorUnitario.toFixed(0);
    document.getElementById("vat01").value = "$" + valorTotal.toFixed(0);
}