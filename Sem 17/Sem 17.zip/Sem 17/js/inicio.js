function validainputs(){
    let email=document.getElementById("email");
    let password=document.getElementById("password");
    let ingreso=document.getElementById("login");
    let emailval=email.value.trim(); //Quitar espacios inesesarios a ambos lados
    let passwordval=password.value.trim();
    let passwordok="a12345"; //Contraseña de ingreso asignada
    var errof=0; //variable de control ingreso-estado sin error
    //seccion de valdacion email
    if(email===""){
        ocErrorform(email,"Por favor ingresa su email");
        errorf=1; //Activa error ocurrido
    }
    else if(!valEmail(emailval)){
        ocErrorform(email,"Email no valido, no cumple formato establecido");
        errorf=1; //Activa error ocurrido
    }
    else{
        exitosform(email);
    }
    //Seccion de validacion password
    if(passwordval===""){
        ocErrorform(password,"Por favor ingresa su contraseña");
        errorf=1; //Activa error ocurrido
    }
    else if(passwordval != passwordok){
        ocErrorform(email,"Contraseña incorrecta...");
        errorf=1; //Activa error ocurrido
    }
    else{
        exitosform(password);
    }
    //Seccion de validacion de ingreso exitoso
    if(errof==0){
        ingreso.addEventListener('click',function() {
        swal("acceso permitido a plataforma web","Click ok para continuar..","success");
    })
}
    //
    return false; //pausa en mensaje de alerta
    //seccion definicon de funcion error
    function ocErrorform(input,message){
        let formControl=input.parentElement;
        let small=formControl.querySelector("small");
        formControl.className="form-control error";
        small.innerText=message;
    }
    //Seccion definicion de funcion exitoso
    function exitosform(input){
        let formControl=input.parentElement;
        formControl.className="form-control success";
    }
    //Expresion regular email
    function valEmail(email){
        return /^[a-z0-9_\.-]+@[a-z\.-]+\.[a-z\.]{2,6}$/.test(email);
        }
    }
//Seccon mostrar contraseña
function mostrarSeña(){
    var tipo=document.getElementById("password");
    if(tipo.type="password"){
        tipo.type="text";//Se muestra la constraseña
    }
    else{
        tipo.type="password";//Se oculta la constraseña
    }
}
